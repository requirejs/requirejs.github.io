define({name:"a",doSomething:function(o){console.log("Hello "+o)}}),console.log("a is done");
//# sourceMappingURL=a.js.map