/**
 * Module A
 */
define({
    name: 'a',
    doSomething: function (name) {
        console.log('Hello ' + name);
    }
});
console.log('a is done');
