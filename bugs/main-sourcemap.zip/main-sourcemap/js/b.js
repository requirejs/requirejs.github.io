define([],function(){var n="b";return{name:n}});
//# sourceMappingURL=b.js.map