/**
 * Module B
 */
define([],function () {
    var name = 'b';
    return {
        name: name
    };
});
