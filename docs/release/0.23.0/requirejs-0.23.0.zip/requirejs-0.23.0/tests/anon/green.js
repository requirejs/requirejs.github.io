require.def({
    name: "green"
});
