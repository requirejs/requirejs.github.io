require.def("red", function () {
    return {
        name: "red"
    };
});