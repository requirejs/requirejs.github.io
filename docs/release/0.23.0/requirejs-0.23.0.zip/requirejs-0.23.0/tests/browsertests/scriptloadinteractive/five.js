def(function () {
    return {
        name: 'five'
    };
});