def(function () {
    return {
        name: 'one'
    };
});