def(function () {
    return {
        name: 'seven'
    };
});