define("dimple",
    {
      color: "dimple-blue"
    }
);
