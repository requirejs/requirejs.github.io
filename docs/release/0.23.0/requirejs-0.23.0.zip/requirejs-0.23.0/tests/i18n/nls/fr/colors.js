require.def({
    red: "rouge",
    blue: "bleu"
});
