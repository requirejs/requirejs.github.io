require.def("map",
  function() {
    return {
      name: "map"
    };
  }
);
