//Just a test file to to use in order build process.
define(["require", "order!one.js", "order!two", "order!three.js"]);
