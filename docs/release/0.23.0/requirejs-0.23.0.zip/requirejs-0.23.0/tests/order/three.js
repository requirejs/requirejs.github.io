//three assumes two has already been loaded
var three = {
    name: "three",
    twoName: two.name
};
