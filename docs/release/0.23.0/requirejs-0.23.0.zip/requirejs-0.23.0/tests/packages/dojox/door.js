require.def({
    name: 'dojox/door'
});
