require.def({
    name: 'dojox/window/pane'
});
