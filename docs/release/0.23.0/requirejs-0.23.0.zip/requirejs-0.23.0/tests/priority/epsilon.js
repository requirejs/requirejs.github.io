define("epsilon",
    {
        name: "epsilon"
    }
);
