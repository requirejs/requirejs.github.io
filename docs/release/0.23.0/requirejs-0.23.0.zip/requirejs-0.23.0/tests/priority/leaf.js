var globalLeafName = "leaf";

require.def("leaf", {
    name: globalLeafName
});
