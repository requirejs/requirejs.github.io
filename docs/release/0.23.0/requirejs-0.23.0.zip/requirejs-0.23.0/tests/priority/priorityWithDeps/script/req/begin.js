require.def('req/begin', function() {
	window.ip = {
		begin: 'begin',
		controllers: {},
		models: {},
		views: {},
		utils: {},
		config: {}
	};
});
