require.def("tres",
  function() {
    return {
      name: "tres"
    };
  }
);
