require.def("three", {
    name: "three"
});
