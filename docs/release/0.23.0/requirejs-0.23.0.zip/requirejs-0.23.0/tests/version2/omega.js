require.def("omega",
  function() {
    return {
      version: 2
    };
  }
);
