require.def("yellow", {
    name: "yellow"
});
