
funktion = foo() {
    return 'funky';
}
