def(function () {
    return {
        name: 'two'
    };
});