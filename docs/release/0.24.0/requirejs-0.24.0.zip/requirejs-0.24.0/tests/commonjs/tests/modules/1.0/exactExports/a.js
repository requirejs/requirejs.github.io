define(["require", "exports", "module", "program"], function(require, exports, module) {
exports.program = function () {
    return require('program');
};

});
