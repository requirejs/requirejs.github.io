require.def("func",
    function () {
        return function () {
            return "You called a function";
        }
    }
);
