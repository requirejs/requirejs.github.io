require.def({
    "root": {
        red: "red",
        blue: "blue",
        green: "green"
    },
    "en-us-surfer": true,
    "fr": true
});
