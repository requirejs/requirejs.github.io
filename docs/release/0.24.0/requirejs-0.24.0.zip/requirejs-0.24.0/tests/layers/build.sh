../../build/build.sh baseUrl=../.. name=require includeRequire=true include=i18n,text,order, out=allplugins-require.js optimize=none
