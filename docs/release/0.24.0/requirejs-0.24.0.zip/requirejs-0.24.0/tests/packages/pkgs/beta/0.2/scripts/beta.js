require.def(function () {
    return 'beta';
});
