//Tests overriding a package path with a more specific mapping.
require.def({
    name: 'fake/alpha/replace'
});
