require.def("foo/bar/two", {
    name: "two"
});
