require.def("foo/three", {
    name: "three"
});
