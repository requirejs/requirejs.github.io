require.def("simple",
  function() {
    return {
      color: "blue"
    };
  }
);
