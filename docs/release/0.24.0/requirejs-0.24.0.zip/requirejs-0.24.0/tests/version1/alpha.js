require.def("alpha",
  function() {
    return {
      version: 1
    };
  }
);
