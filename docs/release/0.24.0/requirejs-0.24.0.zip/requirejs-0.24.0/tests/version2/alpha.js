define("alpha",
  function() {
    return {
      version: 2
    };
  }
);
