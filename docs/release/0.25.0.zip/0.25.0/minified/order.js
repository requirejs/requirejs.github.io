/*
 RequireJS order 0.25.0 Copyright (c) 2010-2011, The Dojo Foundation All Rights Reserved.
 Available via the MIT or new BSD license.
 see: http://github.com/jrburke/requirejs for details
*/
(function(){function g(a,b,c){b([a],function(d){c(function(){return d})})}function j(a){var b=a.currentTarget||a.srcElement,c;if(a.type==="load"||k.test(b.readyState)){a=b.getAttribute("data-requiremodule");h[a]=true;for(a=0;c=e[a];a++)if(h[c.name])g(c.name,c.req,c.onLoad);else break;a>0&&e.splice(0,a);setTimeout(function(){b.parentNode.removeChild(b)},15)}}var l=typeof document!=="undefined"&&typeof window!=="undefined"&&(document.createElement("script").async||window.opera&&Object.prototype.toString.call(window.opera)===
"[object Opera]"||"MozAppearance"in document.documentElement.style),k=/^(complete|loaded)$/,e=[],h={};define({version:"0.25.0",load:function(a,b,c,d){var i=b.nameToUrl(a,null);if(d.isBuild)g(a,b,c);else{require.s.skipAsync[i]=true;if(l)b([a],function(f){c(function(){return f})});else if(b.specified(a))b([a],function(f){c(function(){return f})});else{e.push({name:a,req:b,onLoad:c});require.attach(i,null,a,j,"script/cache")}}}})})();
